/**
 * Created by Emily on 24/04/14.
 */
import java.util.*;



public class Tests {
   // World world1 = new World (10, 10, 7);

}

